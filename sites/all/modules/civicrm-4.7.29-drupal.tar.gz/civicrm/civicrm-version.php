<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.7.29',
                'cms'      => 'Drupal',
                'revision' => '' );
}

