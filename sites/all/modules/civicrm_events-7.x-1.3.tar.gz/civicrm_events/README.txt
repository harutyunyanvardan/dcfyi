--- README  -------------------------------------------------------------

CiviCRM Events

Provides Calendar view for events in CiviCRM.


--- INSTALLATION --------------------------------------------------------

1 - Extract the module into /sites/all/modules directory.

2 - Download the zip  plugin here : http://arshaw.com/fullcalendar/download/

3 - Move the file fullcalendar.js from /fullcalendar-1.5.4/fullcalendar/ into /sites/all/libraries/civicrm_events/
4 - Move the file fullcalendar.css from /fullcalendar-1.5.4/fullcalendar/ into /sites/all/libraries/civicrm_events/

--- USAGE ---------------------------------------------------------------

1 - Enable CiviCRM Events at /admin/modules, (CiviCRM and Libraries required as well)

2 - Go to admin/config/civicrm_events/events_calendar for configuration options of calendar.

3 - Create CiviCRM Events.

4 - You will get events on events/calendar.


Written by: Sushant Paste
