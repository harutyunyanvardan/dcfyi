<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.7.22',
                'cms'      => 'Drupal',
                'revision' => '' );
}

